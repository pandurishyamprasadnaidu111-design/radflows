const o="/assets/portfolio-muneshot-CbPAJpvD.png";export{o as m};
