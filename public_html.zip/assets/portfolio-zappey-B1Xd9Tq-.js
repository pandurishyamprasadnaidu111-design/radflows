const p="/assets/portfolio-zappey-BKLr_U3I.png";export{p as z};
