const s="/assets/portfolio-sapvista-BzGgD1sN.png";export{s};
