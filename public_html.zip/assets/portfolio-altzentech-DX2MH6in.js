const t="/assets/portfolio-altzentech-_dLFPx6O.png";export{t as a};
